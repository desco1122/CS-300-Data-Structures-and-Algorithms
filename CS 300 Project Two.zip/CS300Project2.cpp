/*
**Author:			Daniel Escobedo
* Date/Version:		10/15/2023
* Course:			CS-300 SNHU
* Description:		Week 7 Final Project (Project 2)
*/

#include <string>
#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>

using namespace std;

struct Courses {
    string courseId;
    string courseName;
    vector <string> prerequisites;
};

struct Node {
    Courses course;
    Node* left;
    Node* right;

    Node() {
        left = nullptr;
        right = nullptr;
    }

   
    Node(Courses aCourse) :Node() {
        course = aCourse;
    }
};


 
class BinarySearchTree {

private:
    Node* root;

    void addNode(Node* node, Courses course);
    void inOrder(Node* node);

public:
    BinarySearchTree();
    virtual ~BinarySearchTree();
    void Insert(Courses course);
    void InOrder();
    Courses Search(string courseId);

};


BinarySearchTree::BinarySearchTree() {
    root = nullptr;
}
BinarySearchTree::~BinarySearchTree() {
}



void BinarySearchTree::Insert(Courses course) {
    //adds a new root if root is empty
    if (root == nullptr) {
        root = new Node(course);
    }
    else {
     
        this->addNode(root, course);
    }
}

/**
 * Add a course to some node
 *
 * @param node Current node in tree
 * @param course Courses to be added
 */

void BinarySearchTree::addNode(Node* node, Courses course) {
  
    if (node->course.courseId.compare(course.courseId) > 0) {
        if (node->left == nullptr) {
            node->left = new Node(course);
        }
      
        else {
            this->addNode(node->left, course);
        }
    }
  
    else {
        if (node->right == nullptr) {
            node->right = new Node(course);
        }

        else {
            this->addNode(node->right, course);
        }
    }
}


 
void BinarySearchTree::InOrder() {
    this->inOrder(root);
}

void BinarySearchTree::inOrder(Node* node) {
   
    if (node != nullptr) {
  
        inOrder(node->left);
        cout << node->course.courseId << ", " << node->course.courseName << endl;


        inOrder(node->right);
    }
}


Courses BinarySearchTree::Search(string courseId) {


    Node* current = root;

 
    while (current != nullptr) {
        if (current->course.courseId.compare(courseId) == 0) {
            return current->course;
        }
        if (courseId.compare(current->course.courseId) < 0) {
            current = current->left;
        }
        else {
            current = current->right;
        }
    }
    Courses course;
    return course;
}

void displayCourse(Courses course) {
    cout << course.courseId << ", " << course.courseName << endl;
    cout << "Prerequisites: ";

    if (course.prerequisites.size() == 0) {
        cout << "None";
    }
    else {
        cout << course.prerequisites.at(0);

        for (unsigned int i = 1; i < course.prerequisites.size(); ++i) {
            cout << ", " << course.prerequisites.at(i);
        }
    }
    return;
}

/*
* Opens the file and parses the lines at the comma splitting into tokens
* @parm fileName, BinarySearchTree bst
*/
void courseLoader(string fileName, BinarySearchTree* bst) {
    string token;
    string line;

    int nCount = 0;

    ifstream ABCU;

    //Opens file - File name = ABCU
    ABCU.open(fileName, ios::in);

    if (ABCU.is_open()) {
        cout << "File is open" << endl;
        while (getline(ABCU, line)) {
            vector <string> prerequsites;
            stringstream ss(line);

          
            Courses course;
            nCount = 1;

          

            while (getline(ss, token, ',')) {
                if (nCount == 1) {

                 
                    course.courseId = token;
                }
                
                if (nCount == 2) {
                    course.courseName = token;
                }
               
                if (nCount > 2) {
                    prerequsites.push_back(token);
                }
                ++nCount;
            }

            for (unsigned int i = 0; i < prerequsites.size(); ++i) {
                course.prerequisites.push_back(prerequsites.at(i));
            }
            bst->Insert(course);
        }
    }
    else {
        cout << "File could not be opened" << endl;
    }
};

int main() {
    int menuSelection;
    string fileName;
    string courseSearch;

    BinarySearchTree* bst;
    bst = new BinarySearchTree();
    Courses course;

    do {
        cout << endl;
        cout << "Welcome to the course planner" << endl;
        cout << "*****************************" << endl;
        cout << "* 1.  Load Data Structure.  *" << endl;
        cout << "* 2.  Print Course List.    *" << endl;
        cout << "* 3.  Print Course.         *" << endl;
        cout << "* 9.  Exit                  *" << endl;
        cout << "*****************************" << endl;
        cout << endl;

        do { 

            cin >> menuSelection;
            if (cin.fail()) {
                cin.clear(); 
                cin.ignore(80, '\n');
            }
        } while (cin.fail()); 

        
        switch (menuSelection) {
        case 1:
            cout << "Enter the file name:" << endl;
            
            cin >> fileName;
            courseLoader(fileName, bst);
            cout << endl;
            break; 
        case 2:
            cout << "Here is a sample schedule:" << endl;
            cout << endl;
            bst->InOrder();
            break;
        case 3:
            cout << "What course do you want to know about?" << endl;
            cin >> courseSearch;

            https://www.studymite.com/cpp/examples/changing-case-in-strings-using-cpp
            for (int i = 0; courseSearch[i] != '\0'; i++) {
                if (courseSearch[i] >= 'a' && courseSearch[i] <= 'z')
                    courseSearch[i] = courseSearch[i] - 32;
            }
            cout << endl;
            course = bst->Search(courseSearch);

            if (!course.courseId.empty()) {
                displayCourse(course);
            }
            else {
                cout << "Course " << courseSearch << " not found.";
            }
            cout << endl;
            break;
        case 9:
            cout << "Thank you for using the course planner!" << endl;
            cout << endl;
            break;
        default:
            cout << menuSelection << " is not a valid option." << endl;
            cout << endl;
            break;
        }
        //Exit
    } while (menuSelection != 9);
    return 0;
}